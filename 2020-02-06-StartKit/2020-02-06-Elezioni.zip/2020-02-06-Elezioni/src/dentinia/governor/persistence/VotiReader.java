package dentinia.governor.persistence;

import dentinia.governor.model.Elezioni;

public interface VotiReader {
	public Elezioni getElezioni();
}
