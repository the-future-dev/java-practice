package sudoku.persistence;

import sudoku.model.SudokuBoard;

public interface SudokuReader {

	SudokuBoard getSudoku();

}